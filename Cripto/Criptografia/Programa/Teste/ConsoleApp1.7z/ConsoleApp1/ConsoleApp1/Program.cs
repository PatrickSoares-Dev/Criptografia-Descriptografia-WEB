﻿using PgpCore;
using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {

            //Encrip();
            DEcrip();
        }

        public static void DEcrip()
        {
            using (PGP pgp = new PGP())
            {
                //pgp.DecryptFile(@"D:\20200312\desc\in\LF_BR_tellcall_ekyi_20200214.out.gpg", @"D:\20200312\desc\out\LF_BR_tellcall_ekyi_20200214.out", @"D:\20200110\TCK.asc", "Gi?6ae}a)14Cv&U%&!U#Qp5^j!n+SH@M9_<M7uJluM;s!&L<JkN!fC`#+{q*Wu%");
                //pgp.DecryptFile(@"D:\Valid\Telecall_OP&TK.rar.pgp", @"D:\Valid\Telecall_OP&TK.rar", @"D:\20200110\TCK.asc", "Gi?6ae}a)14Cv&U%&!U#Qp5^j!n+SH@M9_<M7uJluM;s!&L<JkN!fC`#+{q*Wu%");

                //pgp.DecryptFile(@"C:\Users\marcos.cammarota\Documents\Telecall\Criptografia\Criptografia\Arquivos\TOD00001.pgp", @"C:\Users\marcos.cammarota\Documents\Telecall\Criptografia\Criptografia\Arquivos\TOD00001.ota", @"C:\Users\marcos.cammarota\Documents\Telecall\Criptografia\Criptografia\Telecall Keys\9E0F5632E05C7228F9256899D5085A8ABE69EFB4.asc", "Gi?6ae}a)14Cv&U%&!U#Qp5^j!n+SH@M9_<M7uJluM;s!&L<JkN!fC`#+{q*Wu%");

                pgp.DecryptFile(@"C:\Users\marcos.cammarota\Documents\Telecall\Criptografia\Criptografia\Arquivos\LF00030.OTA.pgp", @"C:\Users\marcos.cammarota\Documents\Telecall\Criptografia\Criptografia\Arquivos\LF00030.OTA.inp", @"C:\Users\marcos.cammarota\Documents\Telecall\Criptografia\Criptografia\Telecall Keys\9E0F5632E05C7228F9256899D5085A8ABE69EFB4.asc", "Gi?6ae}a)14Cv&U%&!U#Qp5^j!n+SH@M9_<M7uJluM;s!&L<JkN!fC`#+{q*Wu%");


            }
        }

        public static void Encrip()
        {
            //Install-Package PgpCore -Version 1.2.0
            using (PGP pgp = new PGP())
            {
                //WatchData
                //string[] aChaves = new string[] { @"C:\Users\marcos.cammarota\Documents\Telecall\Criptografia\Criptografia\Public Keys\WatchData\AdH_Watchdata.asc", @"C:\Users\marcos.cammarota\Documents\Telecall\Criptografia\Criptografia\Public Keys\WatchData\lu meng.asc" };

                //pgp.EncryptFileAndSign(@"C:\Users\marcos.cammarota\Documents\Telecall\Criptografia\Criptografia\Arquivos\CUO00001.INP", @"C:\Users\marcos.cammarota\Documents\Telecall\Criptografia\Criptografia\Arquivos\CUO00001.pgp", aChaves, @"C:\Users\marcos.cammarota\Documents\Telecall\Criptografia\Criptografia\Old\20200110\TCK.asc", "Gi?6ae}a)14Cv&U%&!U#Qp5^j!n+SH@M9_<M7uJluM;s!&L<JkN!fC`#+{q*Wu%");


                //TEUM 
                //string[] aChaves = new string[] { @"C:\Users\marcos.cammarota\Documents\Telecall\Criptografia\Criptografia\Public Keys\PARETEUM\PTSecure.asc", @"C:\Users\marcos.cammarota\Documents\Telecall\Criptografia\Criptografia\Public Keys\PARETEUM\Ramy Sayed.asc", @"C:\Users\marcos.cammarota\Documents\Telecall\Criptografia\Criptografia\Public Keys\PARETEUM\Ramy.asc", @"C:\Users\marcos.cammarota\Documents\Telecall\Criptografia\Criptografia\Public Keys\PARETEUM\Teumpub.asc" };

                //pgp.EncryptFileAndSign(@"C:\Users\marcos.cammarota\Documents\Telecall\Criptografia\Criptografia\Arquivos\SIS00002.ota.inp", @"C:\Users\marcos.cammarota\Documents\Telecall\Criptografia\Criptografia\Arquivos\SIS00002.ota.pgp", aChaves, @"C:\Users\marcos.cammarota\Documents\Telecall\Criptografia\Criptografia\Telecall Keys\9E0F5632E05C7228F9256899D5085A8ABE69EFB4.asc", "Gi?6ae}a)14Cv&U%&!U#Qp5^j!n+SH@M9_<M7uJluM;s!&L<JkN!fC`#+{q*Wu%");


                //TEUM2 
                //string[] aChaves = new string[] { @"C:\Users\savio.xavier\Documents\Criptografia\Public Keys\TEUM2\Teumpub.asc" };

                //pgp.EncryptFileAndSign(@"C:\Users\savio.xavier\Documents\Criptografia\Arquivos\LF00019.OUT.OTA", @"C:\Users\savio.xavier\Documents\Criptografia\Arquivos\LF00019.pgp", aChaves, @"C:\Users\savio.xavier\Documents\Criptografia\Telecall Keys\9E0F5632E05C7228F9256899D5085A8ABE69EFB4.asc", "Gi?6ae}a)14Cv&U%&!U#Qp5^j!n+SH@M9_<M7uJluM;s!&L<JkN!fC`#+{q*Wu%");


                //LinksField
                string[] aChaves = new string[] { @"C:\Users\marcos.cammarota\Documents\Telecall\Criptografia\Criptografia\Public Keys\LinksField\linksfield_pk_brasil.asc", @"C:\Users\marcos.cammarota\Documents\Telecall\Criptografia\Criptografia\Public Keys\LinksField\linksfield_publickey.asc" };

                pgp.EncryptFileAndSign(@"C:\Users\marcos.cammarota\Documents\Telecall\Criptografia\Criptografia\Arquivos\LF00030.OTA.INP", @"C:\Users\marcos.cammarota\Documents\Telecall\Criptografia\Criptografia\Arquivos\LF00030.OTA.pgp", aChaves, @"C:\Users\marcos.cammarota\Documents\Telecall\Criptografia\Criptografia\Old\20200110\TCK.asc", "Gi?6ae}a)14Cv&U%&!U#Qp5^j!n+SH@M9_<M7uJluM;s!&L<JkN!fC`#+{q*Wu%");



                // VALID
                //string[] aChaves = new string[] { @"C:\Users\marcos.cammarota\Documents\Telecall\Criptografia\Criptografia\Public Keys\VALID\proceso.ficheros.asc", @"C:\Users\marcos.cammarota\Documents\Telecall\Criptografia\Criptografia\Public Keys\VALID\VALID_TCs.asc" };

                //pgp.EncryptFileAndSign(@"C:\Users\marcos.cammarota\Documents\Telecall\Criptografia\Criptografia\Arquivos\1CL00004.inp", @"C:\Users\marcos.cammarota\Documents\Telecall\Criptografia\Criptografia\Arquivos\1CL00004.pgp", aChaves, @"C:\Users\marcos.cammarota\Documents\Telecall\Criptografia\Criptografia\Old\20200110\TCK.asc", "Gi?6ae}a)14Cv&U%&!U#Qp5^j!n+SH@M9_<M7uJluM;s!&L<JkN!fC`#+{q*Wu%");



                //G&D
                //string[] aChaves = new string[] {@"C:\Users\marcos.cammarota\Documents\Telecall\Criptografia\Criptografia\Public Keys\G&D\GSM_Datagen_Brazil.asc" };

                //pgp.EncryptFileAndSign(@"C:\Users\marcos.cammarota\Documents\Telecall\Criptografia\Criptografia\Arquivos\1CL00004.inp", @"C:\Users\marcos.cammarota\Documents\Telecall\Criptografia\Criptografia\Arquivos\1CL00004.pgp", aChaves, @"C:\Users\marcos.cammarota\Documents\Telecall\Criptografia\Criptografia\Old\20200110\TCK.asc", "Gi?6ae}a)14Cv&U%&!U#Qp5^j!n+SH@M9_<M7uJluM;s!&L<JkN!fC`#+{q*Wu%");
            }
        }
    }
}